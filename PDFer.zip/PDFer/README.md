# PDFer

A minimal, relaxing PDF reader PWA designed for reading screenplays or any PDF.  
**Features:** Upload any PDF, bookmark pages, auto-save your reading place, install to your iPhone home screen!

---

## 🚀 Getting Started

### 1. Unzip the folder

Download and unzip the PDFer.zip package.

### 2. Install Requirements

- [Node.js](https://nodejs.org/) (includes npm)

### 3. Install Dependencies

Open a terminal (command prompt) in the PDFer folder and run:

```
npm install
```

### 4. Run the App

Start the app locally:

```
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📱 Install as a PWA on iPhone

1. Open the app in **Safari** on your iPhone (using your computer's local network IP if needed).
2. Tap the Share button.
3. Select **Add to Home Screen**.
4. PDFer will appear on your home screen—just like a native app!

---

## ✨ Features

- **Upload any PDF** (screenplays, books, etc.)
- **View and navigate pages**
- **Bookmark pages by number**
- **Auto-save your last read page per PDF**
- **Minimal, ambient design**
- **Offline-ready (PWA)**

---

## 💡 Notes

- **Your bookmarks and progress are saved locally (no account needed).**
- **PDF preview may not work in some browser previews—run the app locally for full functionality!**
- For help, just ask!

---

## 🖼️ Attributions

- Logo icon generated via [favicon.io](https://favicon.io)
- Powered by [pdf.js](https://mozilla.github.io/pdf.js/)

---

Enjoy PDFer!